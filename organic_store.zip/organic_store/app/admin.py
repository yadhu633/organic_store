from django.contrib import admin
from.models import *

# Register your models here.
admin.site.register(reguser)
admin.site.register(regshop)
admin.site.register(additem)
admin.site.register(cart)
admin.site.register(order)
admin.site.register(feedback)